import tkinter as tk
import math
import random


class ScientificCalculator:
    def __init__(self, root):
        self.root = root  #menyimpan jendela utama
        self.root.title(" Scientific Calculator") #bikin judul
        self.root.geometry("820x920") #ukuran awal window
        self.root.minsize(650, 700) #ukuran wndow sg boleh lebih kecil dari 650x700
        self.root.configure(bg="#030303")

        self.expression = "" #Simpan oeprasi yang sedang buat
        self.memory = 0      #                      
        self.last_answer = 0   #simpan perhitungan terakhir                      #VARIABEL KALKULATOR
        self.angle_mode = "RAD" #tentukan mode RAD/DEG

        # WARNA GUI
        self.BLACK = "#000000"
        self.DARK = "#1c1c1e"
        self.DARK_HOVER = "#2c2c2e"
        self.GRAY = "#636366"
        self.ORANGE = "#ff9f0a"
        self.ORANGE_HOVER = "#ffb52e"
        self.WHITE = "#f5f5f7"
        self.MUTED = "#a1a1a6"

        self.build_ui()
        self.bind_keyboard()

    def build_ui(self): #untuk membuat samua tampilan
        # ---------------- TOP BAR ----------------
        top = tk.Frame(self.root, bg=self.BLACK) #par container bagian atas
        top.pack(fill="x", padx=30, pady=(20, 5)) #ukurannya

        tk.Label( #kasimuncul kata "kholish deng scientific"
            top,
            text="Kholish",
            font=("Segoe UI", 18, "bold"),
            bg=self.BLACK,
            fg=self.WHITE
        ).pack(side="left")

        tk.Label(
            top,
            text="  SCIENTIFIC",
            font=("Segoe UI", 10),
            bg=self.BLACK,
            fg=self.MUTED
        ).pack(side="left", pady=(6, 0))

        self.angle_button = tk.Button( #bikin tombol RAD
            top,
            text="RAD",
            font=("Segoe UI", 10, "bold"),
            bg=self.DARK,
            fg=self.WHITE,
            activebackground=self.DARK_HOVER,
            activeforeground=self.WHITE,
            relief="flat",
            bd=0,
            padx=14,
            pady=7,
            cursor="hand2",
            command=self.toggle_angle
        )
        self.angle_button.pack(side="right")

        # display (layar kalkulator)
        display = tk.Frame(self.root, bg=self.BLACK)
        display.pack(fill="x", padx=35, pady=(8, 12))

        self.history_display = tk.Label(
            display,
            text="",
            font=("Segoe UI", 13),
            bg=self.BLACK,
            fg=self.MUTED,
            anchor="e"
        )
        self.history_display.pack(fill="x")

        self.main_display = tk.Label(
            display,
            text="0",
            font=("Segoe UI", 52),
            bg=self.BLACK,
            fg=self.WHITE,
            anchor="e"
        )
        self.main_display.pack(fill="x", pady=(0, 5))

        # tombol scientific
        sci = tk.Frame(self.root, bg=self.BLACK)
        sci.pack(fill="x", padx=28)

        scientific_rows = [
            ["(", ")", "mc", "m+", "m-", "mr"],
            ["2nd", "x2", "x3", "xy", "ex", "10x"],
            ["1/x", "sqrt2", "sqrt3", "yroot", "ln", "log10"],
            ["fact", "sin", "cos", "tan", "e", "EE"],
            ["Rand", "sinh", "cosh", "tanh", "pi", "DEG"]
        ]

        for r in range(5):
            sci.rowconfigure(r, weight=1)

        for c in range(6):
            sci.columnconfigure(c, weight=1)

        for r, row in enumerate(scientific_rows):
            for c, key in enumerate(row):
                self.create_button(
                    sci, key, r, c,
                    self.scientific_text(key),
                    self.DARK
                )

        # ---------------- BASIC KEYPAD ----------------
        basic = tk.Frame(self.root, bg=self.BLACK)
        basic.pack(fill="both", expand=True, padx=28, pady=(8, 15))

        for r in range(5):
            basic.rowconfigure(r, weight=1)

        for c in range(4):
            basic.columnconfigure(c, weight=1)

        basic_rows = [
            ["AC", "+/-", "%", "div"],
            ["7", "8", "9", "mul"],
            ["4", "5", "6", "sub"],
            ["1", "2", "3", "add"],
            ["calc", "0", ".", "equals"]
        ]

        for r, row in enumerate(basic_rows):
            for c, key in enumerate(row):
                if key in ("div", "mul", "sub", "add", "equals"):
                    color = self.ORANGE
                elif key in ("AC", "+/-", "%"):
                    color = self.GRAY
                else:
                    color = self.DARK_HOVER

                self.create_button(
                    basic, key, r, c,
                    self.basic_text(key),
                    color
                )

        tk.Label(
            self.root,
            text="Scientific Calculator  â¢  Python + Tkinter",
            font=("Segoe UI", 8),
            bg=self.BLACK,
            fg="#66666b"
        ).pack(pady=(0, 10))

    # ---------------- TEXT ----------------
    def scientific_text(self, key):
        texts = {
            "x2": "x\u00b2",
            "x3": "x\u00b3",
            "xy": "x\u02b8",
            "ex": "e\u02e3",
            "10x": "10\u02e3",
            "sqrt2": "\u00b2\u221ax",
            "sqrt3": "\u00b3\u221ax",
            "yroot": "\u02b8\u221ax",
            "fact": "x!",
            "pi": "\u03c0",
            "log10": "log\u2081\u2080",
            "DEG": "Deg",
            "EE": "EE"
        }
        return texts.get(key, key)

    def basic_text(self, key):
        texts = {
            "div": "\u00f7",
            "mul": "\u00d7",
            "sub": "\u2212",
            "add": "+",
            "equals": "=",
            "calc": "\u232b",
            "+/-": "\u00b1"
        }
        return texts.get(key, key)

    # ---------------- BUTTON ----------------
    def create_button(self, parent, key, text, color):
        btn = tk.Button(
            parent,
            text=text,
            font=("Segoe UI", 14, "bold"),
            bg=color,
            fg=self.WHITE,
            activebackground=self.ORANGE_HOVER if color == self.ORANGE else self.DARK_HOVER,
            activeforeground=self.WHITE,
            relief="flat",
            bd=0,
            cursor="hand2",
            command=lambda k=key: self.press(k)
        )

        btn.grid(
            row=parent.grid_size()[1],
            column=0
        )

        # fungsi grid untuk mengatur poisis tombol seperti tabel
        
        btn.grid_forget()

        
        return btn

    def place_button(self, parent, key, text, color, row, col):
        btn = tk.Button(
            parent,
            text=text,
            font=("Segoe UI", 14, "bold"),
            bg=color,
            fg=self.WHITE,
            activebackground=self.ORANGE_HOVER if color == self.ORANGE else self.DARK_HOVER,
            activeforeground=self.WHITE,
            relief="flat",
            bd=0,
            cursor="hand2",
            command=lambda k=key: self.press(k)
        )
        btn.grid(row=row, column=col, sticky="nsew", padx=4, pady=4)

    # Override build helper with proper geometry
    def create_button(self, parent, key, text, color):
        info = parent.grid_size()
        # grid_size returns current max column/row; caller needs explicit positions,
        # so this method is not used for placement.
        return None

    # ---------------- MODES ----------------
    def toggle_angle(self):
        self.angle_mode = "DEG" if self.angle_mode == "RAD" else "RAD"
        self.angle_button.config(text=self.angle_mode)

    #  CALCULATOR 
    def press(self, key): #fungsi nya par tentukan apa yang terjadi pas tombol ditekan
        if key == "AC": #tombol AC
            self.clear() #fungsi AC par hapus perhitungan

        elif key == "calc": #tombol calc
            self.expression = self.expression[:-1] #par hapus angka terakhir karena :-1
            self.update_display()

        elif key == "equals":
            self.calculate()

        elif key in ("div", "mul", "sub", "add"):
            self.expression += {
                "div": "/",
                "mul": "*",
                "sub": "-",
                "add": "+"
            }[key]
            self.update_display()

        elif key == "+/-":
            if self.expression:
                self.expression = f"-({self.expression})"
                self.update_display()

        elif key == "%":
            self.expression += "/100"
            self.update_display()

        elif key == "x2":
            self.expression += "**2"
            self.update_display()

        elif key == "x3":
            self.expression += "**3"
            self.update_display()

        elif key == "xy":
            self.expression += "**"
            self.update_display()

        elif key == "ex":
            self.expression += "exp("
            self.update_display()

        elif key == "10x":
            self.expression += "10**"
            self.update_display()

        elif key == "1/x":
            self.function("1/x")

        elif key == "sqrt2":
            self.function("sqrt")

        elif key == "sqrt3":
            self.function("cbrt")

        elif key == "yroot":
            self.expression += "**(1/"
            self.update_display()

        elif key in ("sin", "cos", "tan", "sinh", "cosh", "tanh"):
            self.function(key)

        elif key == "ln":
            self.function("ln")

        elif key == "log10":
            self.function("log10")

        elif key == "fact":
            self.function("factorial")

        elif key == "e":
            self.expression += "e"
            self.update_display()

        elif key == "pi":
            self.expression += "pi"
            self.update_display()

        elif key == "EE":
            self.expression += "e"
            self.update_display()

        elif key == "Rand":
            self.expression += str(round(random.random(), 8))
            self.update_display()

        elif key == "mc":
            self.memory = 0

        elif key == "m+":
            try:
                self.memory += float(self.evaluate())
            except Exception:
                pass

        elif key == "m-":
            try:
                self.memory -= float(self.evaluate())
            except Exception:
                pass

        elif key == "mr":
            self.expression += self.format_number(self.memory)
            self.update_display()

        elif key == "2nd":
            self.toggle_second()

        elif key == "DEG":
            self.toggle_angle()

        elif key.isdigit() or key in (".", "(", ")"):
            self.expression += key
            self.update_display()

    def toggle_second(self):
        # Simple 2nd-function behavior: show a status in the history line.
        self.history_display.config(
            text="2nd functions enabled"
        )

    def safe_env(self):
        return {
            "__builtins__": {},
            "pi": math.pi,
            "e": math.e,
            "exp": math.exp
        }

    def evaluate(self):
        return eval(self.expression, self.safe_env())

    def function(self, name):
        try:
            value = float(self.evaluate())

            if name == "sin":
                x = value if self.angle_mode == "RAD" else math.radians(value)
                result = math.sin(x)
            elif name == "cos":
                x = value if self.angle_mode == "RAD" else math.radians(value)
                result = math.cos(x)
            elif name == "tan":
                x = value if self.angle_mode == "RAD" else math.radians(value)
                result = math.tan(x)
            elif name == "sinh":
                result = math.sinh(value)
            elif name == "cosh":
                result = math.cosh(value)
            elif name == "tanh":
                result = math.tanh(value)
            elif name == "ln":
                result = math.log(value)
            elif name == "log10":
                result = math.log10(value)
            elif name == "1/x":
                result = 1 / value
            elif name == "sqrt":
                result = math.sqrt(value)
            elif name == "cbrt":
                result = math.copysign(abs(value) ** (1 / 3), value)
            elif name == "factorial":
                result = math.factorial(int(value))
            else:
                return

            self.history_display.config(
                text=f"{name}({self.format_number(value)})"
            )
            self.expression = self.format_number(result)
            self.last_answer = result
            self.update_display()

        except Exception:
            self.error()

    def calculate(self):
        try:
            if not self.expression:
                return

            original = self.expression
            result = self.evaluate()
            formatted = self.format_number(result)

            self.history_display.config(
                text=original.replace("**", "^")
            )
            self.expression = formatted
            self.last_answer = result
            self.update_display()

        except Exception:
            self.error()

    def format_number(self, value):
        if isinstance(value, float):
            if abs(value) < 1e-12:
                value = 0.0
            if value.is_integer():
                return str(int(value))
            return f"{value:.12g}"
        return str(value)

    def clear(self):
        self.expression = ""
        self.history_display.config(text="")
        self.update_display()

    def error(self):
        self.history_display.config(text="Invalid calculation")
        self.main_display.config(text="Error")
        self.expression = ""

    def update_display(self):
        shown = self.expression or "0"
        shown = shown.replace("pi", "\u03c0")
        shown = shown.replace("**", "^")
        shown = shown.replace("*", "\u00d7")
        shown = shown.replace("/", "\u00f7")
        self.main_display.config(text=shown)

    def bind_keyboard(self):
        self.root.bind("<Return>", lambda e: self.calculate())
        self.root.bind("<BackSpace>", lambda e: self.press("calc"))
        self.root.bind("<Escape>", lambda e: self.clear())
        self.root.bind("<Key>", self.keyboard)

    def keyboard(self, event):
        ch = event.char
        if ch in "0123456789.()+-*/":
            self.expression += ch
            self.update_display()


# Rebuild button placement using a small subclass patch.
# This keeps the main class readable while assigning exact grid positions.
_original_build_ui = ScientificCalculator.build_ui

def patched_build_ui(self):
    # Same UI as above, but with explicit grid placement.
    top = tk.Frame(self.root, bg=self.BLACK)
    top.pack(fill="x", padx=30, pady=(20, 5))

    tk.Label(top, text="KHLSH", font=("Segoe UI", 18, "bold"),
             bg=self.BLACK, fg=self.WHITE).pack(side="left")
    tk.Label(top, text="  SCIENTIFIC", font=("Segoe UI", 10),
             bg=self.BLACK, fg=self.MUTED).pack(side="left", pady=(6, 0))

    self.angle_button = tk.Button(
        top, text="RAD", font=("Segoe UI", 10, "bold"),
        bg=self.DARK, fg=self.WHITE, activebackground=self.DARK_HOVER,
        activeforeground=self.WHITE, relief="flat", bd=0,
        padx=14, pady=7, cursor="hand2", command=self.toggle_angle
    )
    self.angle_button.pack(side="right")

    display = tk.Frame(self.root, bg=self.BLACK)
    display.pack(fill="x", padx=35, pady=(8, 12))

    self.history_display = tk.Label(
        display, text="", font=("Segoe UI", 13),
        bg=self.BLACK, fg=self.MUTED, anchor="e"
    )
    self.history_display.pack(fill="x")

    self.main_display = tk.Label(
        display, text="0", font=("Segoe UI", 52),
        bg=self.BLACK, fg=self.WHITE, anchor="e"
    )
    self.main_display.pack(fill="x", pady=(0, 5))

    sci = tk.Frame(self.root, bg=self.BLACK)
    sci.pack(fill="x", padx=28)
    for r in range(5):
        sci.rowconfigure(r, weight=1)
    for c in range(6):
        sci.columnconfigure(c, weight=1)

    rows = [
        ["(", ")", "mc", "m+", "m-", "mr"],
        ["2nd", "x2", "x3", "xy", "ex", "10x"],
        ["1/x", "sqrt2", "sqrt3", "yroot", "ln", "log10"],
        ["fact", "sin", "cos", "tan", "e", "EE"],
        ["Rand", "sinh", "cosh", "tanh", "pi", "DEG"]
    ]

    for r, row in enumerate(rows):
        for c, key in enumerate(row):
            self.place_button(
                sci, key, self.scientific_text(key),
                self.DARK, r, c
            )

    basic = tk.Frame(self.root, bg=self.BLACK)
    basic.pack(fill="both", expand=True, padx=28, pady=(8, 15))
    for r in range(5):
        basic.rowconfigure(r, weight=1)
    for c in range(4):
        basic.columnconfigure(c, weight=1)

    rows2 = [
        ["AC", "+/-", "%", "div"],
        ["7", "8", "9", "mul"],
        ["4", "5", "6", "sub"],
        ["1", "2", "3", "add"],
        ["calc", "0", ".", "equals"]
    ]

    for r, row in enumerate(rows2):
        for c, key in enumerate(row):
            color = self.ORANGE if key in ("div", "mul", "sub", "add", "equals") else (
                self.GRAY if key in ("AC", "+/-", "%") else self.DARK_HOVER
            )
            self.place_button(
                basic, key, self.basic_text(key),
                color, r, c
            )

    tk.Label(
        self.root,
        text="Scientific Calculator  â¢  Python + Tkinter",
        font=("Segoe UI", 8),
        bg=self.BLACK, fg="#66666b"
    ).pack(pady=(0, 10))

ScientificCalculator.build_ui = patched_build_ui

if __name__ == "__main__":
    root = tk.Tk()
    app = ScientificCalculator(root)
    root.mainloop()